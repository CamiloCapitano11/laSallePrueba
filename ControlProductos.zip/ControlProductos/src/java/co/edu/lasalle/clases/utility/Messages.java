/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.lasalle.clases.utility;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
/**
 *
 * @author CR
 */
public class Messages {
    
    public static void error(String texto, String detalle)
    {
        FacesMessage mensaje = new FacesMessage(FacesMessage.SEVERITY_ERROR, texto, detalle);
        FacesContext.getCurrentInstance().addMessage(null, mensaje);
    }
    
    public static void exito(String texto, String detalle)
    {
        FacesMessage mensaje = new FacesMessage(FacesMessage.SEVERITY_INFO, texto, detalle);
        FacesContext.getCurrentInstance().addMessage("successInfo", mensaje);
    }
}
