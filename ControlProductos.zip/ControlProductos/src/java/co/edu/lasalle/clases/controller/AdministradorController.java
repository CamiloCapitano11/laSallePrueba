/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.lasalle.clases.controller;

import co.edu.lasalle.clases.ejb.AdministradorFacade;
import co.edu.lasalle.clases.persistence.entity.Administrador;
import co.edu.lasalle.clases.utility.Forms;
import co.edu.lasalle.clases.utility.Messages;
import java.io.Serializable;
import java.util.List;
import java.util.ResourceBundle;
import javax.ejb.EJB;
import javax.el.ELContext;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.Application;
import javax.faces.bean.ManagedBean;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.faces.model.SelectItem;

/**
 *
 * @author CR
 */
@ManagedBean(name = "administradorController")
@SessionScoped
public class AdministradorController implements Serializable
{
    @EJB
    private AdministradorFacade _ejbFacade;
    private Administrador _objActual;
    private String _campobusqueda;
    
    /*****************************Para uso en el proceso de selección con flotante**************************************/
    private int _seleccion = -1;
    private String _txtSeleccion = "";

    public AdministradorController() {
        _campobusqueda="";
    }
    
    public Administrador getCampo()
    {
        if (this._objActual == null)
        {
            this._objActual = new Administrador();
        }
        return this._objActual;
    }
    
    public AdministradorFacade getFacade()
    {
        return this._ejbFacade;
    }

    public AdministradorFacade getEjbFacade() {
        return _ejbFacade;
    }

    public void setEjbFacade(AdministradorFacade _ejbFacade) {
        this._ejbFacade = _ejbFacade;
    }

    public Administrador getObjActual() {
        return _objActual;
    }

    public void setObjActual(Administrador _objActual) {
        this._objActual = _objActual;
    }

    public String getCampobusqueda() {
        return _campobusqueda;
    }

    public void setCampobusqueda(String _campobusqueda) {
        this._campobusqueda = _campobusqueda;
    }

    public int getSeleccion() {
        return _seleccion;
    }

    public void setSeleccion(int _seleccion) {
        this._seleccion = _seleccion;
    }

    public String getTxtSeleccion() {
        return _txtSeleccion;
    }

    public void setTxtSeleccion(String _txtSeleccion) {
        this._txtSeleccion = _txtSeleccion;
    }
    
    public List<Administrador> getCiudadesListado() {
        return getFacade().listar();
    }
    
    public SelectItem[] getListadoCombo(String value) {
        return Forms.addObject(getFacade().listar(), value);
    }
    
    public String grabarInstructor()
    {
        String texto, detalle;
        try
        {
            texto = "Éxito";
            detalle = ResourceBundle.getBundle("/com//usta/clases/utility/txtusuarios")
                    .getString("MsgGrabarExito");
            getFacade().grabar(this._objActual);
            Messages.exito(texto, detalle);
            return "instructor";
        }catch (Exception e)
        {
            texto = "Error";
            detalle = e.getMessage();
            Messages.error(texto, detalle);
            return "instructorCrear";
        }
    }
    
    public String borrarInstructor(Administrador objInstructor)
    {
        String texto, detalle;
        this._objActual = objInstructor;
        try
        {
            texto = "Éxito";
            detalle = ResourceBundle.getBundle("/com/usta/clases/utility/txtusuarios")
                    .getString("MsgBorrarExito");
            getFacade().borrar(this._objActual);
            Messages.exito(texto, detalle);
            return "instructor";
        }
        catch(Exception e)
        {
            texto = "Error";
            detalle = e.getMessage();
            Messages.error(texto, detalle);
            return "instructor";
        }
    }

    public List<Administrador> getInstructorListado() {
        return getFacade().listar();
    }
    
    public String buscar(){
        return "instructor";
    }
    
    public List<Administrador> getInstructorBuscar(){
        System.out.println(""+_campobusqueda);
        return getFacade().searchByfield("_nombreUsuario",_campobusqueda);
    }
    
    public String verInstructor(Administrador objInstructor) {
        this._objActual = objInstructor;
        return "instructorEditar";
    }

    public String actualizarInstructor() {
        String texto, detalle;
        try {
            texto = "Exito se actualizó el usuario " + String.valueOf(this._objActual.getIdAdministrador());
            detalle = ResourceBundle.getBundle("/com/usta/clases/utility/txtusuarios")
                    .getString("MsgEditarExito");
            getFacade().actualizar(this._objActual);
            Messages.exito(texto, detalle);
            return "instructor";
        } catch (Exception e) {
            texto = "Error";
            detalle = e.getMessage();
            Messages.error(texto, detalle);
            return "instructorEditar";
        }
    }
    
    public void limpiar(){
        this._objActual = null;
    }
    
    //************************************************************
    //Interface Converter
    //************************************************************
    
    @FacesConverter(forClass = Administrador.class, value = "instructorConverter")
    public static class InstructorControllerConverter implements Converter
    {

        @Override
        public Object getAsObject(FacesContext context, UIComponent component, String value) 
        {
            try
            {
                int id = Integer.parseInt(value);
                AdministradorController controlador;
                ELContext contextoExterno = context.getELContext();
                Application contextoAplicacion = context.getApplication();
                String nombreDecoracionControlador = "instructorController";
                
                controlador = (AdministradorController) contextoAplicacion.getELResolver().getValue(contextoExterno, null, nombreDecoracionControlador);
                return controlador.getFacade().buscar(id);
            }
            catch(NumberFormatException error)
            {
                //Mensajes.error("Error", error.getMessage());
                return null;
            }
        }

        @Override
        public String getAsString(FacesContext context, UIComponent component, Object value) {
            if (value instanceof Administrador)
            {
                Administrador obj = (Administrador) value;
                return String.valueOf(obj.getIdAdministrador());
            }
            return null;
        }
    }
    //****************************************************************************
    //End Controller
}
