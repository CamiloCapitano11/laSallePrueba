/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.lasalle.clases.controller;

import co.edu.lasalle.clases.ejb.ClienteFacade;
import co.edu.lasalle.clases.persistence.entity.Cliente;
import co.edu.lasalle.clases.utility.Forms;
import co.edu.lasalle.clases.utility.Messages;
import java.io.Serializable;
import java.util.List;
import java.util.ResourceBundle;
import javax.ejb.EJB;
import javax.el.ELContext;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.Application;
import javax.faces.bean.ManagedBean;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.faces.model.SelectItem;

/**
 *
 * @author CR
 */
@ManagedBean(name = "clienteController")
@SessionScoped
public class ClienteController implements Serializable
{
    @EJB
    private ClienteFacade _ejbFacade;
    private Cliente _objActual;
    private String _campobusqueda;
    
    /*****************************Para uso en el proceso de selección con flotante**************************************/
    private int _seleccion = -1;
    private String _txtSeleccion = "";

    public ClienteController() {
        _campobusqueda="";
    }
    
    public Cliente getCampo()
    {
        if (this._objActual == null)
        {
            this._objActual = new Cliente();
        }
        return this._objActual;
    }
    
    public ClienteFacade getFacade()
    {
        return this._ejbFacade;
    }

    public ClienteFacade getEjbFacade() {
        return _ejbFacade;
    }

    public void setEjbFacade(ClienteFacade _ejbFacade) {
        this._ejbFacade = _ejbFacade;
    }

    public Cliente getObjActual() {
        return _objActual;
    }

    public void setObjActual(Cliente _objActual) {
        this._objActual = _objActual;
    }

    public String getCampobusqueda() {
        return _campobusqueda;
    }

    public void setCampobusqueda(String _campobusqueda) {
        this._campobusqueda = _campobusqueda;
    }

    public int getSeleccion() {
        return _seleccion;
    }

    public void setSeleccion(int _seleccion) {
        this._seleccion = _seleccion;
    }

    public String getTxtSeleccion() {
        return _txtSeleccion;
    }

    public void setTxtSeleccion(String _txtSeleccion) {
        this._txtSeleccion = _txtSeleccion;
    }
    
    public List<Cliente> getCiudadesListado() {
        return getFacade().listar();
    }
    
    public SelectItem[] getListadoCombo(String value) {
        return Forms.addObject(getFacade().listar(), value);
    }
    
    public String grabarCliente()
    {
        String texto, detalle;
        try
        {
            texto = "Éxito";
            detalle = ResourceBundle.getBundle("/co/edu/lasalle/clases/utility/txtusuarios")
                    .getString("MsgGrabarExito");
            getFacade().grabar(this._objActual);
            Messages.exito(texto, detalle);
            return "cliente";
        }catch (Exception e)
        {
            texto = "Error";
            detalle = e.getMessage();
            Messages.error(texto, detalle);
            return "clienteCrear";
        }
    }
    
    public String borrarCliente(Cliente objCliente)
    {
        String texto, detalle;
        this._objActual = objCliente;
        try
        {
            texto = "Éxito";
            detalle = ResourceBundle.getBundle("/co/edu/lasalle/clases/utility/txtusuarios")
                    .getString("MsgBorrarExito");
            getFacade().borrar(this._objActual);
            Messages.exito(texto, detalle);
            return "cliente";
        }
        catch(Exception e)
        {
            texto = "Error";
            detalle = e.getMessage();
            Messages.error(texto, detalle);
            return "cliente";
        }
    }

    public List<Cliente> getClienteListado() {
        return getFacade().listar();
    }
    
    public String buscar(){
        return "cliente";
    }
    
    public List<Cliente> getClienteBuscar(){
        System.out.println(""+_campobusqueda);
        return getFacade().searchByfield("_nombreUsuario",_campobusqueda);
    }
    
    public String verCliente(Cliente objCliente) {
        this._objActual = objCliente;
        return "clienteEditar";
    }

    public String actualizarCliente() {
        String texto, detalle;
        try {
            texto = "Exito se actualizó el usuario " + String.valueOf(this._objActual.getCuentaList());
            detalle = ResourceBundle.getBundle("/co/edu/lasalle/clases/utility/txtusuarios")
                    .getString("MsgEditarExito");
            getFacade().actualizar(this._objActual);
            Messages.exito(texto, detalle);
            return "cliente";
        } catch (Exception e) {
            texto = "Error";
            detalle = e.getMessage();
            Messages.error(texto, detalle);
            return "clienteEditar";
        }
    }
    
    public void limpiar(){
        this._objActual = null;
    }
    
    //************************************************************
    //Interface Converter
    //************************************************************
    
    @FacesConverter(forClass = Cliente.class, value = "clienteConverter")
    public static class ClaseControllerConverter implements Converter
    {

        @Override
        public Object getAsObject(FacesContext context, UIComponent component, String value) 
        {
            try
            {
                int id = Integer.parseInt(value);
                ClienteController controlador;
                ELContext contextoExterno = context.getELContext();
                Application contextoAplicacion = context.getApplication();
                String nombreDecoracionControlador = "clienteController";
                
                controlador = (ClienteController) contextoAplicacion.getELResolver().getValue(contextoExterno, null, nombreDecoracionControlador);
                return controlador.getFacade().buscar(id);
            }
            catch(NumberFormatException error)
            {
                //Mensajes.error("Error", error.getMessage());
                return null;
            }
        }

        @Override
        public String getAsString(FacesContext context, UIComponent component, Object value) {
            if (value instanceof Cliente)
            {
                Cliente obj = (Cliente) value;
                return String.valueOf(obj.getIdCliente());
            }
            return null;
        }
    }
    //****************************************************************************
    //End Controller
}
