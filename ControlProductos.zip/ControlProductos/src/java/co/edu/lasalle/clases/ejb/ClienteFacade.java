/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.lasalle.clases.ejb;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import co.edu.lasalle.clases.persistence.entity.Cliente;
import java.util.List;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
/**
 *
 * @author CR
 */
@Stateless
public class ClienteFacade extends Abstract<Cliente>
{
    @PersistenceContext(name = "ControlProductosPU")
    private EntityManager _em;
    
    @Override
    protected EntityManager getAdmEntity()
    {
        return this._em;
    }
    
    public ClienteFacade()
    {
        super(Cliente.class);
    }
    
    public List<Cliente> searchByfield(String atributo, String texto) {
        CriteriaBuilder cb = getAdmEntity().getCriteriaBuilder();
        CriteriaQuery<Cliente> cq = cb.createQuery(Cliente.class);
        Root<Cliente> objCliente = cq.from(Cliente.class);
        if (!texto.equals("")) {
            Expression<String> campo = objCliente.get(atributo);
            campo = cb.lower(campo);
            String cadena = "%" + texto.toLowerCase() + "%";
            Predicate condicion = cb.like(campo, cadena);
            cq.where(condicion);
        }
        Query consulta = getAdmEntity().createQuery(cq);
        return consulta.getResultList();
    }
}
