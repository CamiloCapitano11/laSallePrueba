/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.lasalle.clases.utility;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author iflr
 */
public class EncryptPassword {

    public String encryptPassword(String password) throws NoSuchAlgorithmException {

        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        byte[] bs;
        StringBuilder stringBuilder = new StringBuilder();
        messageDigest.reset();
        bs = messageDigest.digest(password.getBytes());
        for (int i = 0; i < bs.length; i++) {
            String hexVal = Integer.toHexString(0xFF & bs[i]);
            if (hexVal.length() == 1) {
                stringBuilder.append("0");
            }
            stringBuilder.append(hexVal);
        }
        return stringBuilder.toString().toUpperCase();
    }
    
    /*public static void main(String[] args) {
        EncryptPassword ep = new EncryptPassword();
        String cadena="123";
        
        try {
            cadena=ep.encryptPassword(cadena);
            System.out.println("clave: "+cadena);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(EncryptPassword.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/

}
