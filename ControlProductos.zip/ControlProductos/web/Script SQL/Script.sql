CREATE TABLE persona(
	id_persona SERIAL NOT NULL PRIMARY KEY,
	nombre VARCHAR(150) NOT NULL,
	documento VARCHAR(20) NOT NULL,
	fecha_nacimiento DATE NOT NULL
);

CREATE TABLE usuario(
	id_usuario SERIAL NOT NULL PRIMARY KEY,
	nombre_usuario VARCHAR(100) NOT NULL,
	contrasenia VARCHAR(100) NOT NULL,
	id_persona INT NOT NULL
);

CREATE TABLE cliente(
	id_cliente SERIAL NOT NULL PRIMARY KEY,
	id_usuario INT NOT NULL
);

CREATE TABLE administrador(
	id_administrador SERIAL NOT NULL PRIMARY KEY,
	id_usuario INT NOT NULL	
);

CREATE TABLE tipo_cuenta(
	id_tipo_cuenta SERIAL NOT NULL PRIMARY KEY,
    tipo_cuenta VARCHAR(100) NOT NULL
);

CREATE TABLE cuenta(
	id_cuenta SERIAL NOT NULL PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_tipo_cuenta INT NOT NULL,
	numero_cuenta VARCHAR(200) NOT NULL
);

ALTER TABLE usuario ADD FOREIGN KEY (id_persona) REFERENCES persona(id_persona);
ALTER TABLE cliente ADD FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario);
ALTER TABLE administrador ADD FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario);
ALTER TABLE cuenta ADD FOREIGN KEY (id_tipo_cuenta) REFERENCES tipo_cuenta(id_tipo_cuenta);
ALTER TABLE cuenta ADD FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente);