/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.lasalle.clases.controller;

import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

/**
 *
 * @author USUARIO
 */
@Named(value = "access")
@SessionScoped
public class Access implements Serializable {

    private String user;
    private String password;

    /**
     * Creates a new instance of Access
     */
    public Access() {
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String signIn() throws ServletException {
        String page = "index";
        System.out.println(user + " - " + password);
        HttpServletRequest petition = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        try {
            petition.login(user, password);
            page = "index?faces-redirect=true&rol=noEncontrado";
            if (petition.isUserInRole("adminface")) {
                page = "Instructor/index?faces-redirect=true";
            } else {
                if (petition.isUserInRole("clientface")) {
                    page = "Cliente/index?faces-redirect=true";
                } else {
                    petition.logout();
                }
            }
        } catch (ServletException e) {
            password = null;
            Logger.getLogger(Access.class.getName()).log(Level.SEVERE, null, e);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Datos Incorrectos"));
        }
        return page;
    }

    public void exit() {
        try {
            ExternalContext externContext = FacesContext.getCurrentInstance().getExternalContext();
            externContext.invalidateSession();
            externContext.redirect("../index.xhtml?sesion?=cerrar");
        } catch (IOException ex) {
            Logger.getLogger(Access.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
