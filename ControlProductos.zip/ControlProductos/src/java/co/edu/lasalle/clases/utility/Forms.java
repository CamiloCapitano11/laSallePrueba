/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.lasalle.clases.utility;

import java.util.List;
import javax.faces.model.SelectItem;

/**
 *
 * @author CR
 */
public class Forms {
    public static SelectItem[] addObject(List<?> objectsList, String textFirstChoise){
        int index,size;
        SelectItem[] itemsList;
        
        index = 0; 
        size = objectsList.size();
        if(textFirstChoise != null && !textFirstChoise.isEmpty()){
            size = size +1;
            index = index + 1;
            itemsList = new SelectItem[size];
            itemsList[0] = new SelectItem("", textFirstChoise);
        }else{
            itemsList = new SelectItem[size];
        }
        
        for(Object obj: objectsList){
            itemsList[index] = new SelectItem(obj, obj.toString());
            index++;
        }
        return itemsList;
    }
}