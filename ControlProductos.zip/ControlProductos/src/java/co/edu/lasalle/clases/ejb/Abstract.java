/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.lasalle.clases.ejb;


import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
/**
 *
 * @author CR
 */
public abstract class Abstract<T> 
{
    private final Class<T> entidad;
    protected abstract EntityManager getAdmEntity();
    
    public Abstract(Class<T> entidad)
    {
        this.entidad = entidad;
    }
    
    public void grabar(T entidad){
        getAdmEntity().persist(entidad);
    }
    
    public void borrar(T entidad){
        getAdmEntity().remove(getAdmEntity().merge(entidad));
    }
    
    public void actualizar(T entidad){
        getAdmEntity().merge(entidad);
    }
    
    public T buscar(Object id){
       return getAdmEntity().find(entidad, id);
    }
    
    public List<T> listar()
    {
        CriteriaBuilder cb = getAdmEntity().getCriteriaBuilder();
        CriteriaQuery<T> cq = cb.createQuery(entidad);
        cq.select(cq.from(entidad));
        List<T> allData = getAdmEntity().createQuery(cq).getResultList();
        return allData;
    }
}
